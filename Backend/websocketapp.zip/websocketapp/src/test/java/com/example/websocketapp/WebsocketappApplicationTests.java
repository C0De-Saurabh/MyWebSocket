package com.example.websocketapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsocketappApplicationTests {

	@Test
	void contextLoads() {
	}

}
